package com.ftptransfer.app

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } }
        }
    }
}

private fun SharedPreferences.load(p: String) = FtpConfig(
    getString("${p}_host", "") ?: "",
    getString("${p}_port", "21") ?: "21",
    getString("${p}_user", "") ?: "",
    getString("${p}_pass", "") ?: "",
    getString("${p}_path", "/") ?: "/"
)

private fun SharedPreferences.save(p: String, c: FtpConfig) = edit()
    .putString("${p}_host", c.host).putString("${p}_port", c.port)
    .putString("${p}_user", c.user).putString("${p}_pass", c.pass)
    .putString("${p}_path", c.path).apply()

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("ftp_settings", 0) }
    val scope = rememberCoroutineScope()
    val view = LocalView.current

    var src by remember { mutableStateOf(prefs.load("src")) }
    var dst by remember { mutableStateOf(prefs.load("dst")) }
    var reverse by remember { mutableStateOf(prefs.getBoolean("reverse", false)) }
    var skip by remember { mutableStateOf(prefs.getBoolean("skip", true)) }
    var running by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    val logs = remember { mutableStateListOf<String>() }
    var status by remember { mutableStateOf("") }

    // Layar tetap menyala selama proses berjalan
    SideEffect { view.keepScreenOn = running }

    fun saveAll() {
        prefs.save("src", src); prefs.save("dst", dst)
        prefs.edit().putBoolean("reverse", reverse).putBoolean("skip", skip).apply()
        status = "Pengaturan disimpan"
    }

    fun addLog(s: String) {
        scope.launch(Dispatchers.Main) {
            logs.add(s)
            if (logs.size > 300) logs.removeRange(0, logs.size - 300)
        }
    }

    fun start() {
        saveAll()
        val from = if (reverse) dst else src
        val to = if (reverse) src else dst
        if (from.host.isBlank() || to.host.isBlank()) {
            status = "Alamat FTP sumber/tujuan belum diisi"; return
        }
        logs.clear(); running = true; status = "Memproses..."
        job = scope.launch {
            try {
                val st = withContext(Dispatchers.IO) {
                    transfer(from, to, skip, { isActive }, ::addLog)
                }
                status = if (!isActive) "Dibatalkan"
                else "Selesai: ${st.copied} disalin, ${st.skipped} dilewati, ${st.failed} gagal " +
                    "(${st.bytes / 1024 / 1024} MB)"
            } catch (e: CancellationException) {
                status = "Dibatalkan"
            } catch (e: Exception) {
                status = "Error: ${e.message}"
                addLog("ERROR: ${e.message}")
            } finally {
                running = false
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(16.dp).statusBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("FTP → FTP Transfer", style = MaterialTheme.typography.headlineSmall)

        ConfigCard("Server Sumber", src, !running) { src = it }
        ConfigCard("Server Tujuan", dst, !running) { dst = it }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Arah transfer", style = MaterialTheme.typography.labelMedium)
                        Text(
                            if (!reverse) "Sumber  →  Tujuan" else "Tujuan  →  Sumber",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    OutlinedButton(onClick = { reverse = !reverse }, enabled = !running) {
                        Text("Tukar arah")
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(skip, { skip = it }, enabled = !running)
                    Text("Lewati file yang sudah ada (ukuran sama)")
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { saveAll() }, enabled = !running, modifier = Modifier.weight(1f)) {
                Text("Simpan")
            }
            if (!running) {
                Button(onClick = { start() }, modifier = Modifier.weight(2f)) { Text("PROSES") }
            } else {
                Button(
                    onClick = { job?.cancel() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.weight(2f)
                ) { Text("BATAL") }
            }
        }

        if (running) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodyMedium)

        if (logs.isNotEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(8.dp)) {
                    logs.takeLast(40).forEach {
                        Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun ConfigCard(title: String, c: FtpConfig, enabled: Boolean, onChange: (FtpConfig) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    c.host, { onChange(c.copy(host = it)) }, label = { Text("Alamat FTP") },
                    singleLine = true, enabled = enabled, modifier = Modifier.weight(2f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                OutlinedTextField(
                    c.port, { onChange(c.copy(port = it.filter(Char::isDigit))) },
                    label = { Text("Port") }, singleLine = true, enabled = enabled,
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
            OutlinedTextField(
                c.user, { onChange(c.copy(user = it)) }, label = { Text("User") },
                singleLine = true, enabled = enabled, modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                c.pass, { onChange(c.copy(pass = it)) }, label = { Text("Password") },
                singleLine = true, enabled = enabled, modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation()
            )
            OutlinedTextField(
                c.path, { onChange(c.copy(path = it)) }, label = { Text("Folder (mis. /data/foto)") },
                singleLine = true, enabled = enabled, modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
