package com.ftptransfer.app

import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import java.io.IOException

data class FtpConfig(
    val host: String = "",
    val port: String = "21",
    val user: String = "",
    val pass: String = "",
    val path: String = "/"
)

data class Stats(var copied: Int = 0, var skipped: Int = 0, var failed: Int = 0, var bytes: Long = 0)

private fun normalize(p: String): String {
    val t = p.trim().trim('/')
    return if (t.isEmpty()) "/" else "/$t"
}

private fun join(base: String, name: String) = if (base == "/") "/$name" else "$base/$name"

private fun connect(c: FtpConfig): FTPClient {
    val f = FTPClient()
    f.connectTimeout = 20_000
    f.defaultTimeout = 60_000
    f.setDataTimeout(java.time.Duration.ofSeconds(60))
    f.controlKeepAliveTimeout = java.time.Duration.ofSeconds(30)
    f.connect(c.host.trim(), c.port.trim().toIntOrNull() ?: 21)
    if (!f.login(c.user, c.pass)) {
        f.disconnect()
        throw IOException("Login gagal ke ${c.host}")
    }
    f.enterLocalPassiveMode()
    f.setFileType(FTP.BINARY_FILE_TYPE)
    f.bufferSize = 64 * 1024
    return f
}

private fun ensureDir(f: FTPClient, path: String) {
    var cur = ""
    for (part in path.split("/").filter { it.isNotEmpty() }) {
        cur += "/$part"
        if (!f.changeWorkingDirectory(cur)) f.makeDirectory(cur)
    }
    f.changeWorkingDirectory("/")
}

private fun copyDir(
    src: FTPClient, dst: FTPClient, srcPath: String, dstPath: String,
    skipExisting: Boolean, active: () -> Boolean, log: (String) -> Unit, st: Stats
) {
    if (!active()) return
    ensureDir(dst, dstPath)
    val items = src.listFiles(srcPath) ?: throw IOException("Gagal membaca folder $srcPath")
    for (item in items) {
        if (!active()) return
        val name = item.name
        if (name == "." || name == ".." || name.isNullOrEmpty()) continue
        val sp = join(srcPath, name)
        val dp = join(dstPath, name)
        when {
            item.isDirectory -> copyDir(src, dst, sp, dp, skipExisting, active, log, st)
            item.isFile -> {
                try {
                    if (skipExisting) {
                        val ex = dst.listFiles(dp)
                        if (ex != null && ex.size == 1 && ex[0].isFile && ex[0].size == item.size) {
                            st.skipped++
                            log("Lewati: $sp")
                            continue
                        }
                    }
                    log("Salin: $sp")
                    val input = src.retrieveFileStream(sp)
                        ?: throw IOException("Tidak bisa membuka $sp")
                    val ok = input.use { dst.storeFile(dp, it) }
                    val done = src.completePendingCommand()
                    if (ok && done) {
                        st.copied++
                        st.bytes += item.size
                    } else {
                        st.failed++
                        log("GAGAL: $sp")
                    }
                } catch (e: IOException) {
                    st.failed++
                    log("GAGAL: $sp (${e.message})")
                }
            }
        }
    }
}

/** Menyalin isi folder dari server [from] ke server [to] secara langsung (streaming, tanpa simpan lokal). */
fun transfer(
    from: FtpConfig, to: FtpConfig, skipExisting: Boolean,
    active: () -> Boolean, log: (String) -> Unit
): Stats {
    val st = Stats()
    var a: FTPClient? = null
    var b: FTPClient? = null
    try {
        log("Menghubungkan ke ${from.host}...")
        a = connect(from)
        log("Menghubungkan ke ${to.host}...")
        b = connect(to)
        copyDir(a, b, normalize(from.path), normalize(to.path), skipExisting, active, log, st)
    } finally {
        try { a?.logout() } catch (_: Exception) {}
        try { a?.disconnect() } catch (_: Exception) {}
        try { b?.logout() } catch (_: Exception) {}
        try { b?.disconnect() } catch (_: Exception) {}
    }
    return st
}
