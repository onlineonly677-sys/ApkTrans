# FTP Transfer
Cara build APK:
A) Android Studio: File > Open folder ini > Build > Build APK(s)
B) GitHub: upload folder ini ke repo baru > tab Actions > Build APK > unduh artifact "FtpTransfer-apk"
